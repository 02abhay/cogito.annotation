import json

# input output json file

input_file = open('dataloop.json', 'r')
output_file = open('labelMe2.json', 'w')
json_decode = json.load(input_file)

# acess_data=print(json_decode)

# print(type(json_decode))

# iterating in input file

shapes =[]


for item in json_decode['annotations']:
    # my_dict = {}

    acess_data=item['metadata']["system"]["snapshots_"]
    print(acess_data)

    shapes = []
    for obj in acess_data:
        b = obj['data']

        d = dict(
            label='carbox',
            line_color='null',
            fill_collor='null',
            shape_type='polygun',
            flag={},
            lineColor='null',
            fillColor='null',


        )
        shapes.append(d)

        def data(List,mydata):
            for dict in List:
                if (dict['data']==mydata):
                    print(data)



shapes.append(acess_data)

# creating output file
back_json = json.dumps(shapes)
output_file.write(back_json)
output_file.close()




