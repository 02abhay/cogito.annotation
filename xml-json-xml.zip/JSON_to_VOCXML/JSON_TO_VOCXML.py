# Program to read JSON file
# and generate its XML file

# Importing json module and xml
# module provided by python
import json as JS
import xml.etree.ElementTree as ET
import xml.dom.minidom

# Opening JSON file in read mode
with open("../2000607036-3ft-edc-34.jpg___objects.json", "r") as json_file:
    # loading json file data
    # to variable data

    data = JS.load(json_file)
    root=ET.Element('root')
    # row is part of root element
    row = ET.SubElement(root, "row")


    # points = ET.SubElement(row, "points")
    ET.SubElement(row, "type").text=str(data[0]["type"])
    ET.SubElement(row, "classId").text = str(data[0]["classId"])
    ET.SubElement(row, "probability").text = str(data[0]["probability"])

    points = data[0]["points"]
    # ET.SubElement(root, "poloygun").text = str(data["poloygun"])

    # Now creating loop and read the data  from json
    for i in points:

        ET.SubElement(row, "points").text = str(i)

    ET.SubElement(row, "className").text = str(data[0]["className"])
    # ET.SubElement(row, "type").text = data["type"]

    # ET.SubElement(points, "points").text = str(data[0]["points"])
    # ET.SubElement(row, "classBody").text = str(data["classBody"]

    # Building the tree of the xml
    # elements using the root element



    tree = ET.ElementTree(root)

    # Writing the xml to output file
    tree.write("json_to_VocXML.xml")





