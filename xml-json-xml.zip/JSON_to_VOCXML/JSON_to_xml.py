# Program to read JSON file
# and generate its XML file

# Importing json module and xml
# module provided by python
import json as JS
import xml.etree.ElementTree as ET
import xml.dom.minidom

# Opening JSON file in read mode
with open("../2000607036-3ft-edc-34.jpg___objects.json", "r") as json_file:
    # loading json file data
    # to variable data
    data = JS.load(json_file);

    # print(data)

    # Building the root element
    # of the xml file

    root = ET.Element("root")
    row=ET.SubElement(root,'row')
    type=ET.SubElement(root,'poloygun')
    classId=ET.SubElement(root,'classId')
    probability=ET.SubElement(root,'probability')

    points=ET.SubElement(root,"points")
    points.text = ''

for i in data[0]['points']:
    points.text+=str(i)


    # i=0
    # points=ET.SubElement(root,'points')
    # ET.SubElement(points,'points').text=str(i['points'])

    # print(points)
    # print(i)

   #  points.append(points.text)
    #  ET.SubElement(points,'points').text=str(i['points'])
    # points.text = points.text +'\n\t\t\t' + i
   # print(points)

# OUTPUT AND PRETTY PRINT TREE

tree_out = ET.tostring(root, encoding="UTF-8")
newXML = xml.dom.minidom.parseString(tree_out.decode('UTF-8'))
pretty_xml = newXML.toprettyxml()
print(pretty_xml)

# tree=ET.ElementTree(root)
# tree.write("annotate.xml")
with open('../Output2.xml', 'w') as f:
    f.write(pretty_xml)




