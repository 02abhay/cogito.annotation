import json

# input output json file

input_file = open('dataloop.json', 'r')
output_file = open('labelMe.json', 'w')
json_decode = json.load(input_file)
print(json_decode)
# iterating in input file

var=json_decode['annotations']['coordinate']
data = []



for item in var:
    my_dict = {}
    imagePath = "9703858_Hasar_9703858_1586853916_7442.jpg"


    # data['points'] = data.pop('coordinates')
    # data['points']=['coordinates']

    # my_dict['labels']=item.get('labels')
    # my_dict['description']=item.get('points')
    # my_dict['shape_type']=item.get('shape_type')
    # print(my_dict)


    data.append(item)
# creating output file
back_json = json.dumps(data)
output_file.write(back_json)
output_file.close()

