# Program to read JSON file
# and generate its XML file

# Importing json module and xml
# module provided by python


import json as JS
import xml.etree.ElementTree as ET
import xml.dom.minidom

# Opening JSON file in read mode
with open("dataloop.json", "r") as json_file:
    # loading json file data
    # to variable data
    data = JS.load(json_file);
    annotations = ET.Element('annotations')
    # row is part of root element
    folder = ET.SubElement(annotations, "folder")

    ET.SubElement(annotations, "filename").text = str(data["filename"])
    ET.SubElement(annotations, "path").text = str("IMG_jeff@fruitscout.ai_1596730554.830069.jpg")

    # nowcreating subelement of annotations
    source = ET.SubElement(annotations, "source")
    ET.SubElement(source, "database").text = str("Unknown")

    size = ET.SubElement(annotations, "size")
    ET.SubElement(size, "widh").text = str(4608)
    ET.SubElement(size, "height").text = str(3456)
    ET.SubElement(size, "depth").text = str(3)

    segmented = ET.SubElement(annotations, "segmented")

    object = ET.SubElement(annotations, "object")

    ET.SubElement(object, "name").text = str("AnjouPears")
    ET.SubElement(object, "pose").text = str("Unspecified")
    ET.SubElement(object, "truncated").text = str(0)
    ET.SubElement(object, "difficult").text = str(0)

    # bndbox=ET.SubElement(object, "bndbox")

    # bndbox=data['annotations'][0]['coordinates']

    for a_dict in data['annotations']:
        # print(a_dict,'\n')
        bndbox = a_dict['coordinates']
        # print(bndbox)
        c_dict = {
            'xmin': bndbox[0]['x'],
            'ymin': bndbox[0]['y'],
            'xmax': bndbox[1]['x'],
            'ymax': bndbox[1]['y'],
        }
        # c_dict['xmin']=bndbox[0]['x']
        # c_dict['ymin'] = bndbox[0]['y']
        # c_dict['xmax'] = bndbox[1]['x']
        # c_dict['ymax'] = bndbox[1]['y']

        print(c_dict)

        # ET.SubElement(object, "bndbox")=c_dict

    # for i in bndbox:
    #     ET.SubElement(object, "bndbox").text = str(i.keys)
    #
    #
    #     print(i)
    #
    #
    # bndbox=data['annotations'][2]['coordinates'][0]
    #
    #
    # for i in bndbox:
    #     ET.SubElement(annotations, "object").text = str(i)
    #     # print(i)

tree = ET.ElementTree(annotations)

# Writing the xml to output file
tree.write("datalooptoVocXML.xml")




