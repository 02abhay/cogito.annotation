import json
# input output json file
input_file = open('dataloop.json', 'r')
output_file = open('labelMe.json', 'w')
json_decode = json.load(input_file)

# acess_data=print(json_decode)
# print(type(json_decode))
# iterating in input file

def val(obj):
    # print(obj)
    # xx = []
    # for i in obj:
    #     xx.append([i['x'], i['y']])

    return [[o['x'], o['y']] for o in obj]

shapes = []
for item in json_decode['annotations']:
    # my_dict = {}
    cords = item.get('coordinates')
    obj = dict(
            # imagePath="9703858_Hasar_9703858_1586853916_7442.jpg",
            # imageHeight="3200",
            # imageWidth="4300",
            # imageData='null',
            label='carbox',
            line_color='null',
            fill_collor='null',
            shape_type='polygun',
            flags={},
            lineColor='null',
            fillColor='null',
        )

    if cords:
        #print(1, cords[0])
        if type(cords[0]) == type([]):
            obj['points'] = val(cords[0])
        else:
            obj['points'] = val(cords)

        #obj['points'] = [val(ob) if type(ob) == type([]) else [[ob['x'], ob['y']]] for ob in cords]
        shapes.append(obj)
    # acess_data=item['metadata']["system"]["snapshots_"]
    # print(acess_data)

    #printing extra variables in dictionary

main_obj = dict(
            # label='carbox',
            # line_color='null',
            # fill_collor='null',
            # shape_type='polygun',
            imagePath="9703858_Hasar_9703858_1586853916_7442.jpg",
            imageHeight="3200",
            imageWidth="4300",
            imageData='null',
            flags={},
            line_color='null',
            fill_collor='null',

        )


main_obj['shapes'] = shapes
#print(main_obj)
# shapes.append(acess_data)
# creating output file
back_json = json.dumps(main_obj)
output_file.write(back_json)
output_file.close()

